package SistemaFacturacion;

public class NuevoClienteDialog {
    private java.awt.Dialog dialog;
    private java.awt.TextField txtNombre, txtApellido, txtCedula, txtTelefono, txtDireccion, txtEmail;
    private ListaClientes listaClientes;
    private Cliente cliente;

    public NuevoClienteDialog(ListaClientes listaClientes, Cliente cliente) {
        this.listaClientes = listaClientes;
        this.cliente = cliente;

        dialog = new java.awt.Dialog(new java.awt.Frame(), cliente == null ? "Nuevo Cliente" : "Editar Cliente", true);
        dialog.setSize(400, 300);
        dialog.setLayout(new java.awt.GridLayout(7, 2));

        dialog.add(new java.awt.Label("Nombre:"));
        txtNombre = new java.awt.TextField(cliente != null ? cliente.getNombre() : "");
        dialog.add(txtNombre);

        dialog.add(new java.awt.Label("Apellido:"));
        txtApellido = new java.awt.TextField(cliente != null ? cliente.getApellido() : "");
        dialog.add(txtApellido);

        dialog.add(new java.awt.Label("Cédula:"));
        txtCedula = new java.awt.TextField(cliente != null ? cliente.getCedula() : "");
        dialog.add(txtCedula);

        dialog.add(new java.awt.Label("Teléfono:"));
        txtTelefono = new java.awt.TextField(cliente != null ? cliente.getTelefono() : "");
        dialog.add(txtTelefono);

        dialog.add(new java.awt.Label("Dirección:"));
        txtDireccion = new java.awt.TextField(cliente != null ? cliente.getDireccion() : "");
        dialog.add(txtDireccion);

        dialog.add(new java.awt.Label("Email:"));
        txtEmail = new java.awt.TextField(cliente != null ? cliente.getEmail() : "");
        dialog.add(txtEmail);

        java.awt.Button btnGuardar = new java.awt.Button("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                guardarCliente();
            }
        });

        dialog.add(new java.awt.Label());
        dialog.add(btnGuardar);

        dialog.setVisible(true);
    }

    private void guardarCliente() {
        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        String cedula = txtCedula.getText();
        String telefono = txtTelefono.getText();
        String direccion = txtDireccion.getText();
        String email = txtEmail.getText();

        if (cliente == null) {
            cliente = new Cliente(nombre, apellido, cedula, telefono, direccion, email);
            listaClientes.agregarOActualizarCliente(cliente);
        } else {
            cliente.setNombre(nombre);
            cliente.setApellido(apellido);
            cliente.setCedula(cedula);
            cliente.setTelefono(telefono);
            cliente.setDireccion(direccion);
            cliente.setEmail(email);
        }

        dialog.dispose();
    }
}

package SistemaFacturacion;

public class FormularioPrincipal {
    private java.awt.Frame frame;
    private java.awt.Button btnListaClientes;
    private java.awt.Button btnSalir;
    private ListaClientes listaClientes;

    public FormularioPrincipal() {
        frame = new java.awt.Frame("Sistema de Facturación 1.0.0");
        frame.setSize(400, 200);
        frame.setLayout(new java.awt.FlowLayout());

        btnListaClientes = new java.awt.Button("Lista de Clientes");
        btnSalir = new java.awt.Button("Salir");
        listaClientes = new ListaClientes();

        btnListaClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                listaClientes.mostrar();
            }
        });

        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                frame.dispose();
            }
        });

        frame.add(btnListaClientes);
        frame.add(btnSalir);
        frame.setVisible(true);
    }
}

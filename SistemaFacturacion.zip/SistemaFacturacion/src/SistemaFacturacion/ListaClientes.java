package SistemaFacturacion;

public class ListaClientes {
    private java.awt.Frame frame;
    private java.awt.List listaClientes;
    private java.awt.Button btnAgregar;
    private java.awt.Button btnEditar;
    private java.util.ArrayList<Cliente> clientes;

    public ListaClientes() {
        frame = new java.awt.Frame("Lista de Clientes");
        frame.setSize(500, 400);
        frame.setLayout(new java.awt.BorderLayout());

        clientes = new java.util.ArrayList<>();
        listaClientes = new java.awt.List();
        btnAgregar = new java.awt.Button("Agregar Cliente");
        btnEditar = new java.awt.Button("Editar Cliente");

        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                abrirFormularioNuevoCliente(null);
            }
        });

        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                int index = listaClientes.getSelectedIndex();
                if (index >= 0) {
                    abrirFormularioNuevoCliente(clientes.get(index));
                } else {
                    mostrarMensaje("Seleccione un cliente para editar.");
                }
            }
        });

        java.awt.Panel panelBotones = new java.awt.Panel();
        panelBotones.add(btnAgregar);
        panelBotones.add(btnEditar);

        frame.add(listaClientes, java.awt.BorderLayout.CENTER);
        frame.add(panelBotones, java.awt.BorderLayout.SOUTH);
    }

    public void mostrar() {
        actualizarLista();
        frame.setVisible(true);
    }

    private void actualizarLista() {
        listaClientes.removeAll();
        for (Cliente cliente : clientes) {
            listaClientes.add(cliente.toString());
        }
    }

    private void abrirFormularioNuevoCliente(Cliente cliente) {
        new NuevoClienteDialog(this, cliente);
    }

    public void agregarOActualizarCliente(Cliente cliente) {
        if (!clientes.contains(cliente)) {
            clientes.add(cliente);
        }
        actualizarLista();
    }

    private void mostrarMensaje(String mensaje) {
        java.awt.Frame mensajeFrame = new java.awt.Frame("Mensaje");
        java.awt.Label label = new java.awt.Label(mensaje);
        mensajeFrame.setSize(200, 100);
        mensajeFrame.add(label);
        mensajeFrame.setVisible(true);
    }
}

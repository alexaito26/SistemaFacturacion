/**
 * 
 */
/**
 * 
 */
module SistemaFacturacion {
	requires java.desktop;
}